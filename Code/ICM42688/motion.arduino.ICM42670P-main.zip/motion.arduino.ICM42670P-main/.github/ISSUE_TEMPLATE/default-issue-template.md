---
name: Default issue template
about: Default issue template to notify maintainers team
title: ''
labels: ''
assignees: ''

---

_Your text here_

---
Notify: @tdk-invn-oss/motion-maintainers @tdk-invn-oss/arduino-maintainers
